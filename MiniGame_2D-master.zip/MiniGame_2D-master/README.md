# MiniGame_2D

### 文件目录结构

目录划分方式参考https://gameinstitute.qq.com/community/detail/105229

如有添加修改请及时更新目录说明。

```c#
MiniGame_2D
	|- Assets // 存放所有游戏资源
		|- 3nd // 存放所有第三方类库
  	|- Scenes // 游戏场景
		|- Scripts // 游戏脚本
			|- Model
			|- View
			|- Controller
		|- Resources // 存放基础资源
			|- Font // 存放字体相关资源
			|- Prefabs // 预储存文件
			|- Audio // 音频文件
	|- Packages 
		|- ...
```

### 文件提交规范
#### .meta 文件提交规范
参考http://ixulin.com/2017/07/05/talk-unity-meta/
##### 1. 第一次添加文件必须同时提交.meta文件
比如添加了a.fbx，第一次提交fbx时必须同时提交a.fbx.meta。之后的人除了修改了fbx的导入配置参数外不允许再提交.meta文件（防止guid被修改）。
##### 2. 关于.meta文件的移动删除
删除文件的svn提交，请同时提交.meta文件的删除。
移动文件请同时移动meta文件

### 房间场景说明(06.02)

现有三个房间场景`room1`,`room2`,`room3`,只有room1搭载了`GameManager`(已实现单例化)。从`room1`开始运行游戏，按任意`1` `2` `3`可进行场景切换(该方法只供测试使用，写于`GameManager`的`update`方法中，实际应使用`门`进行场景切换)。任意房间的地图随机生成，一旦房间随机生成后，再次返回该房间(即切换回该场景)房间布置不发生改变。

