﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BoardController : MonoBehaviour
{
    public GameObject[] floor;  // 地板样式
    public GameObject[] walls;  // 墙的样式
    public GameObject[] barriers;   // 障碍物的样式
    public GameObject[] doors;  // 门的样式
    public int rows = 10;    // 房间横宽
    public int columns = 10; // 房间纵长
    List<Vector3> positions = new List<Vector3>();  // 可以放置物品的位置
    List<Vector3> lack_positions = new List<Vector3>();     // 缺失的地板位置
    private PolygonCollider2D Collider2D;
    private GameManager g;

    private int left = -9;
    private int right = 22;
    private int up = 3;
    private int down = -6;

    private int level = 1;

    public static Dictionary<string,GameObject> rooms = new Dictionary<string,GameObject>();    // 保存已经加载的场景内容

    GameObject Room;    // 房间收纳
    Transform Floor;    // 地板收纳面板
    Transform OutWall;  // 外墙收纳面板
    Transform Barriers; // 障碍物收纳面板
    Transform Doors;    // 门收纳面板

    void Start(){
        Collider2D = GameObject.Find("Positions").GetComponent<PolygonCollider2D>();
    }

    public void SetupScene(string scene_name){
        // 隐藏当前所有GameObject
        GameObject root = GameObject.Find("Room");
        if (root){
            root.SetActive(false);
        }
        Debug.Log(scene_name);
        if (rooms.ContainsKey(scene_name)){
            Debug.Log("Contain "+ scene_name);
            rooms[scene_name].SetActive(true);
        }
        else{
            // 初始化
            positions.Clear();
            lack_positions.Clear();
            // 新建场景
            BoardSetup();
            // 收纳场景
            Room = new GameObject("Room");
            Floor.transform.SetParent(Room.transform);
            OutWall.transform.SetParent(Room.transform);
            Barriers.transform.SetParent(Room.transform);
            Doors.transform.SetParent(Room.transform);
            // 保存房间场景
            rooms.Add(scene_name,Room);
            Debug.Log("Add "+scene_name);
            
        }
    DontDestroyOnLoad(Room);
    }

    public void BoardSetup(){
        // Floor = new GameObject("Floor").transform;
        // OutWall = new GameObject("OutWall").transform;
        // Barriers = new GameObject("Barriers").transform;
        // Doors = new GameObject("Doors").transform;
        Debug.Log("BOARD");

        int enemy_count = Random.Range(7,12);
        List<Vector2> Overlaps = GetAreas();

        // 生成敌人
        for (int i=0;i<enemy_count;i++){
            int x,y;
            Vector2 pos;
            do{
                // 随机生成x,y
                x = Random.Range(left,right);
                y = Random.Range(down,up);
                pos = new Vector2(x,y);
            }while (!PositionPnpoly(Overlaps,pos));
            g = GetComponent<GameManager>();
            g.CreatNewEnemy(pos,Quaternion.identity,Enum.Enemy.Type1);
        }

		//切换主相机
		GameManager.Instance.CanvaOnCamera.GetComponent<Canvas>().worldCamera = Camera.main;
		Debug.Log("change camera");

		// 生成房间
		//CreatRoom();

		// 生成障碍物
		//CreatBarrier();
	}

    public bool PositionPnpoly(List<Vector2> Overlaps, Vector2 p)
    {
 
        int i, j, c = 0;
        for (i = 0, j = Overlaps.ToArray().Length - 1; i < Overlaps.ToArray().Length; j = i++)
        {
            
            if (((Overlaps[i].y > p.y) != (Overlaps[j].y > p.y)) && (p.x < (Overlaps[j].x - Overlaps[i].x) * (p.y - Overlaps[i].y) / (Overlaps[j].y - Overlaps[i].y) + Overlaps[i].x))
            {
               // Debug.Log(i);
                c = 1 + c; ;
            }
        }
        if (c % 2 == 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    List<Vector2> GetAreas(){
        Collider2D = GameObject.Find("Positions").GetComponent<PolygonCollider2D>();
        Debug.Log("Find Positions");
        Debug.Log("Transform "+transform.position);
        List<Vector2> vector = new List<Vector2>();
        for (int i = 0; i < Collider2D.GetTotalPointCount(); i++)
        {
            //本地坐标变为屏幕坐标
            vector.Add(new Vector2(transform.position.x, transform.position.y) + Collider2D.points[i]);
            //Debug.Log(vector[i]);
        }
        return vector;
    }

    // 实例化物品
    void CreatThing(GameObject origin,Vector3 position,Quaternion rotation,Transform holder){
        // 创造副本
        GameObject toInstance = origin;
        // 实例化
        GameObject instance = Instantiate(toInstance,position,rotation);
        // 放入收纳面板
        instance.transform.SetParent(holder);
    }

    /*
        生成房间的障碍物,count = 4*level
    */
    void CreatBarrier(){
        int count = level*4;
        for (int i=0;i<count;i++){
            int index = Random.Range(0,positions.Count);
            Vector3 position = positions[index];
            GameObject origin = barriers[Random.Range(0,barriers.Length)];
            CreatThing(origin,position,Quaternion.identity,Barriers);
            positions.RemoveAt(index);
            
        }
    }

    void CreatDoor(List<Vector3> pos){
        if (pos.Count!=0){
            int index = Random.Range(0,pos.Count);
            GameObject origin = doors[Random.Range(0,doors.Length)];
            Vector3 position = pos[index];
            CreatThing(origin,position,Quaternion.identity,Doors);
            lack_positions.Add(position);
        }

    }

    /*
        生成房间的地板和外墙
    */
    void CreatRoom(){
        
        List<Vector3> left = new List<Vector3>();
        List<Vector3> right = new List<Vector3>();
        List<Vector3> up = new List<Vector3>();
        List<Vector3> down = new List<Vector3>();

        // 确定房间的不规则形状
        for(int i = 0;i < columns;i++){
            if (Random.Range(0,10)<5){
                // 50%概率缺失某一块
                lack_positions.Add(new Vector3(0,i,0f));
            }
            else{
                // 有效的门的位置
                left.Add(new Vector3(0,i,0f));
            }
            if (Random.Range(0,10)<5){
                // 50%概率缺失某一块
                lack_positions.Add(new Vector3(rows-1,i,0f));
            }
            else{
                // 有效的门的位置
                right.Add(new Vector3(rows-1,i,0f));
            }

        }


        for(int i = 0;i < rows;i++){
            if (Random.Range(0,10)<5){
                // 50%概率缺失某一块
                lack_positions.Add(new Vector3(i,0,0f));
            }
            else{
                // 有效的门的位置
                down.Add(new Vector3(i,0,0f));
            }

            if (Random.Range(0,10)<5){
                // 50%概率缺失某一块
                lack_positions.Add(new Vector3(i,columns-1,0f));
            }
            else{
                // 有效的门的位置
                up.Add(new Vector3(i,columns-1,0f));
            }


        }

        // 放门，四边各放一个
        CreatDoor(left);
        CreatDoor(right);
        CreatDoor(up);
        CreatDoor(down);
        

        // 摆放地板
        for (int i = 0;i<rows;i++){
            for (int j=0;j<columns;j++){
                if (!lack_positions.Contains(new Vector3(i,j,0f))){
                    GameObject origin = floor[Random.Range(0,floor.Length)];
                    Vector3 position = new Vector3(i,j,0f);
                    CreatThing(origin,position,Quaternion.identity,Floor);
                    positions.Add(position);
                }
            }
        }

        // 摆放墙体
        // 左右的墙体 i=-1
        int y = 0;
        while(y<columns){
            // 左边的墙
            // 可以摆放墙
            if (positions.Contains(new Vector3(0,y,0f))){
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(-1,y,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            else{
                // 在该位置的右侧摆放墙
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(0,y,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            // 右边的墙
            // 可以摆放墙
            if (positions.Contains(new Vector3(rows-1,y,0f))){
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(rows,y,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            else{
                // 在该位置的左侧摆放墙
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(rows-1,y,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);            
            }
            y++;
        }
        // 上下的墙
        int x = 0;
        while(x<rows){
            // 下面的墙
            // 可以摆放墙
            if (positions.Contains(new Vector3(x,0,0f))){
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(x,-1,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            else{
                // 在该位置的上侧摆放墙
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(x,0,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            // 上面的墙
            // 可以摆放墙
            if (positions.Contains(new Vector3(x,columns-1,0f))){
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(x,columns,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            else{
                // 在该位置的下侧摆放墙
                GameObject origin = walls[Random.Range(0,walls.Length)];
                Vector3 position = new Vector3(x,columns-1,0f);
                CreatThing(origin,position,Quaternion.identity,OutWall);
            }
            x++;
        }


    }
}
