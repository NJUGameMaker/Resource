﻿using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;

public class BulletController : MonoBehaviour
{

	private Rigidbody2D rigidbody2;
	private Vector2 speed;
	private Enum.Weapon type;
	private float power;
	//伤害持续时间
	private float damageTime;
	//动画持续时间
	private float showTime;
	private Enum.Owner owner;

	public Owner Owner { get => owner; }
	public float Power { get => power; }

	public BulletController SetUp(Vector2 s,float p,float dt,float st,Enum.Weapon t,Enum.Owner o)
	{
		damageTime = dt;
		showTime = st;
		speed = s;
		speed *= Mathf.Max(1, p * 2);
		power = p;
		type = t;
		owner = o;
		//根据蓄力改变大小
		//gameObject.transform.localScale *= Mathf.Max(1,p*2);
		return this;
	}

	// Start is called before the first frame update
	void Start()
    {
		rigidbody2 = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
		rigidbody2.velocity = speed;
		damageTime -= Time.deltaTime;
		showTime -= Time.deltaTime;
		if (damageTime < 0)
			Destroy(gameObject);
    }
	

	private void OnTriggerEnter2D(Collider2D collision)
	{
		if (damageTime < 0)
			return;
		//Debug.Log(collision.gameObject.tag);
		switch (type)
		{
			case Weapon.Type1:
				break;
			case Weapon.Type2:
				if (collision.gameObject.tag == "Wall" || 
					(collision.gameObject.tag == "Enemy" && owner == Owner.Player) ||
					(collision.gameObject.tag == "PlayerView" && owner == Owner.Enemy))
					Destroy(gameObject);
				break;
			case Weapon.Size:
				break;
		}
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
		//Debug.Log(collision.gameObject.tag);

		//if (collision.gameObject.tag == "Wall" || collision.gameObject.tag == "Enemy")
		//	Destroy(gameObject);
	}
}
