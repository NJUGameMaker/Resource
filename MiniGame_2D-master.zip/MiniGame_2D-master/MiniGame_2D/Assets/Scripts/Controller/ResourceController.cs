﻿using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;

public class ResourceController : MonoBehaviour
{
	private Resource typer;
	private Equip typee;
	private int num;
	private GameObject follow;
	private TimeLock timeLock;

	public Equip Typee { get => typee; }
	public Resource Typer { get => typer; }
	public int Num { get => num; }

	public ResourceController SetUp(Resource type,int n = 1)
	{
		typer = type;
		typee = Equip.Size;
		num = n;
		return this;
	}

	public ResourceController SetUp(Equip type, int n = 1)
	{
		typee = type;
		typer = Resource.Size;
		num = n;
		return this;
	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		//Debug.Log(other.gameObject.tag);
		if (other.gameObject.tag == "Player" && !timeLock.Working)
		{
            if (typer != Resource.Size) PlayerData.Instance.ModifyResource(typer, num);
            if (typee != Equip.Size) PlayerData.Instance.ModifyEquip(typee, num);
			follow = other.gameObject;
			timeLock.Last = 1f;
			Destroy(gameObject, 1f);
		}
	}

	// Start is called before the first frame update
	void Start()
    {
		timeLock = new TimeLock();
    }

    // Update is called once per frame
    void Update()
    {
        if (timeLock.Working)
		{
			timeLock.Last -= Time.deltaTime;
			transform.position += (follow.transform.position - transform.position) * 0.1f;
			transform.localScale *= 0.9f;
		}
    }
}
