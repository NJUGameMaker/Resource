﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

	private GameObject playerView;
	private GameObject weapon;
	private Rigidbody2D rigidbody;
	private SpriteRenderer render;
	private WeaponController weaponcontroller;
	private TimeLock timeLock;
	private float beAttack;
	private float nowSpeed;

	public static PlayerController Instance;

	private bool is_rotate = false;
	private bool is_look_rotate;
	private Animator animator;

	private void Awake()
	{
		if (Instance == null)
		{
			// 初始化单例
			Instance = this;
		}
		else if (Instance != this)
		{
			// 单例已存在 消除现在的GameManager
			Destroy(gameObject);
		}
		// 切换场景时不消除
		DontDestroyOnLoad(gameObject);
	}


	// Start is called before the first frame update
	void Start()
    {
		timeLock = new TimeLock();
		playerView = GameObject.FindGameObjectWithTag("PlayerView");
		weapon = GameObject.FindGameObjectWithTag("Weapon");
		rigidbody = GetComponent<Rigidbody2D>();
		render = playerView.GetComponent<SpriteRenderer>();
		weaponcontroller = weapon.GetComponent<WeaponController>();
		animator = playerView.GetComponent<Animator>();
	}

	void UpdateRigibody()
	{
		//Vector2 tmpVec = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
		//tmpVec.Normalize();
		//tmpVec *= PlayerData.Instatnce.Speed;
		//rigidbody.velocity = tmpVec;
		//if (!timeLock.Working)

		//Debug.Log("New Frame");
		float GetVer = Input.GetAxisRaw("Vertical");
		float GetHor = Input.GetAxisRaw("Horizontal");
		//Debug.Log("Ver: "+GetVer);
		//Debug.Log("Hor: "+GetHor);
		rigidbody.velocity = StaticFunction.NormoalSize(new Vector2(GetHor, GetVer), PlayerData.Instance.Speed);
		if (GetVer<0){
			rundown();
		}
		else if(GetVer>0){
			runup();
		}
		else if(GetHor>0){
			runright();
		}
		else if(GetHor<0){
			runleft();
		}
		else if(GetHor==0 && GetVer==0){
			runstill();
		}

		//if (beAttack <= 0)
		//{
		//	nowSpeed += 0.2f;
		//nowSpeed = Mathf.Min(PlayerData.Instance.Speed, nowSpeed);
		//	rigidbody.velocity = StaticFunction.NormoalSize(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), nowSpeed);
		//}
		//else
		//{
		//	beAttack -= Time.deltaTime;
		//}
		//rigidbody.velocity = StaticFunction.NormoalSize(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), PlayerData.Instance.Speed);

		Vector2 look = StaticFunction.Vec3ToVec2(transform.position - Camera.main.ScreenToWorldPoint(Input.mousePosition));
		render.flipX = (look.x > 0);
		if (look.x>0){
			// 向左
			//Debug.Log("Look=true");
			is_look_rotate = false;
		}
		else{
			// 向右
			//Debug.Log("Look=false");
			is_look_rotate = true;
		}
		weaponcontroller.Rotate(StaticFunction.Vec2ToRot(look));
	}

	private void runstill(){
        animator.SetBool("right",false);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
        //Debug.Log("is_rotate: "+is_rotate);
        //Debug.Log("is_look_rotate: "+is_look_rotate);
        if (!(is_rotate^is_look_rotate)){
            //已经旋转
            transform.rotation = Quaternion.Euler(0, 0, 0);
            is_rotate = false;
        }
	}

	private void runleft(){
        //Debug.Log("run left");
        //Debug.Log(is_rotate);
        //Debug.Log("is_rotate: "+is_rotate);
        //Debug.Log("is_look_rotate: "+is_look_rotate);
        if ((is_rotate^is_look_rotate)){
            //未旋转
            transform.rotation = Quaternion.Euler(0, 0, 0);
            is_rotate = true;
        }
        animator.SetBool("right",true);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
    }

    private void rundown(){
        animator.SetBool("down",true);
        animator.SetBool("Up",false);
        animator.SetBool("right",false);
    }

    private void runright(){
        //Debug.Log("run right");
        //Debug.Log(is_rotate);
        if (is_rotate==true){
            //已经旋转
            transform.rotation = Quaternion.Euler(0, 0, 0);
            is_rotate = false;
        }
        animator.SetBool("right",true);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
    }

    private void runup(){
        animator.SetBool("up",true);
        animator.SetBool("down",false);
        animator.SetBool("right",false);
    }

	public void UpdateCamera()
	{
		var mov = transform.position - Camera.main.transform.position;
		mov.z = 0;
		mov *= 0.08f;
		Camera.main.transform.position += mov;
	}

	public void BeAttack(GameObject collision, int damage, float time, float force)
	{
		if (!timeLock.Working)
		{
			//Debug.Log(damage);
			timeLock.Last = time;
			GameManager.Instance.CreatNewSlider(this.gameObject, time, () => { return PlayerData.Instance.Health*1.0f / PlayerData.Instance.MaxHealth; }, Color.red, Color.black);
			StartCoroutine(StaticFunction.RenderFlash(render, timeLock, 0.2f));
			rigidbody.velocity = (StaticFunction.NormoalSize(StaticFunction.Vec3ToVec2(transform.position - collision.transform.position), force));
			PlayerData.Instance.Health -= damage;
			beAttack = 0.5f;
			nowSpeed = 0;
		}
	}

	private void OnTriggerEnter2D(Collider2D collision)
	{
		//Debug.Log(collision.gameObject.tag);

		//var ec = collision.gameObject.GetComponentInParent<EnemyController>();
		//if (collision.gameObject.tag == "EnemyAttack" && !timeLock.Working)
		//{
		//	BeAttack(collision, Mathf.Max(0, ConstData.EnemyAtrTable[(int)ec.Type, (int)Enum.Attribute.Health]), 2, 10); 
		//}
	}

	// Update is called once per frame
	void Update()
    {
		UpdateRigibody();
		UpdateCamera();
	}

    public void Death()
    {
        //Do something
        //Set time.timescale to 0, this will cause animations and physics to stop updating
        Time.timeScale = 0;
        //call the ShowPausePanel function of the ShowPanels script
        GameObject.Find("Over").transform.localScale = new Vector3(1, 1, 1);
    }

}
