﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class DoorController : MonoBehaviour
{
    private string from;
    private string to;

    private BoardController boardController;
    private bool isGo;
    private bool isCreateTo;
    private bool isLeft;

    private GameObject selfDoor;

    // 门所对应的图片资源
    private Dictionary<Enum.Door,string> doorImages = new Dictionary<Enum.Door,string>(){
        {Enum.Door.Type1,"Goods/door1"},
        {Enum.Door.Type2,"Goods/door2"},
        {Enum.Door.Type3,"Goods/door3"}
    };

    public Vector3 leftDoor;
    public Vector3 rightDoor;

    // Start is called before the first frame update
    void Start()
    {

    }

    // 获取当前脚本所挂载的门
    private void GetSelf(){
        if (isLeft){
            selfDoor = GameObject.Find("leftChooseDoor");
        }
        else{
            selfDoor = GameObject.Find("rightChooseDoor");
        }
    }

    /*
        创建门的时候调用
    */
    public bool SetDoor(string sceneName,bool direct,Enum.Door type){
        //资源消耗
        int require1 = ConstData.DoorResTable[(int)type, 0];
        int require2 = ConstData.DoorResTable[(int)type, 1];
        if (PlayerData.Instance.GetResouce(Enum.Resource.Type1) > require1 
            && PlayerData.Instance.GetResouce(Enum.Resource.Type2) > require2)
        {
            PlayerData.Instance.ModifyResource(Enum.Resource.Type1, - require1);
            PlayerData.Instance.ModifyResource(Enum.Resource.Type2, - require2);
        }
        else{
            return false;
        }

        // 当前场景名
        from = SceneManager.GetActiveScene ().name;
        // 穿过门的方向
        isGo = true;
        // 连接的下一个场景
        to = sceneName;
        // 下一个场景是否被加载
        isCreateTo = false;
        // 门的位置
        isLeft = direct;
        //// 更换门的图片资源
        //Image IMGE = transform.Find("Door1").GetComponent<Image>();
        //Sprite sprite = Resources.Load(doorImages[type], typeof(Sprite)) as Sprite;
        //IMGE.sprite = sprite;
        //// 显示门
        //GetSelf();
        //selfDoor.transform.localScale = new Vector3(1,1,1);
        return true;
    }

    /*
        穿过门的时候调用
    */
    public void GoToNext(){
        // 判断方向
        if (isGo){
            SceneManager.LoadScene(to);
           isGo = false;
            if(!isCreateTo){
                // 显示一个门
                if (isLeft){
                    // 如果是左边的门进入的，就不显示左边的门
                    GameObject door = GameObject.Find("leftChooseDoor");
                    door.transform.localScale = new Vector3(0,0,0);
                }
                else{
                    GameObject door = GameObject.Find("rightChooseDoor");
                    door.transform.localScale = new Vector3(0,0,0);
                }
            }
        }
        else{
            SceneManager.LoadScene(from);
            isGo = true;
        }
		//切换主相机
		GameManager.Instance.CanvaOnCamera.GetComponent<Canvas>().worldCamera = Camera.main;
		Debug.Log("change camera");
	}

}
