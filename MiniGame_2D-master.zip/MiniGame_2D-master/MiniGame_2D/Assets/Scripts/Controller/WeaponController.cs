﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class WeaponController : MonoBehaviour
{

    //判断UI层
    public EventSystem eventsystem;
    public GraphicRaycaster graphicRaycaster;

    private float power;
    private SliderController powerSlider;
    private float cdtime;

    private Animator animator;

    public void Rotate(float r)
    {
        transform.rotation = Quaternion.Euler(0, 0, r);
    }

    // Start is called before the first frame update
    void Start()
    {
        powerSlider = null;
        animator = GameObject.FindGameObjectWithTag("WeaponView").GetComponent<Animator>();
    }

    private void AddPower()
    {
        if (powerSlider)
        {
            powerSlider.Time = 10;
        }
        power += 2f * Time.deltaTime;
        power = Mathf.Min(1, power);
    }

    private void Fire()
    {
        Debug.Log("Fire");
        if (powerSlider)
        {
            Destroy(powerSlider.gameObject);
            powerSlider = null;
            animator.SetTrigger("hit");
        }
        else{
            animator.SetTrigger("attack");
        }
		//根据武器类型设置子弹属性
		switch (PlayerData.Instance.Weapon)
		{
			case Enum.Weapon.Type1:
				GameManager.Instance.CreatNewBullet(gameObject, PlayerData.Instance.Weapon, StaticFunction.RotToVec2(transform.rotation) * 0, power,0.1f,0.5f,Enum.Owner.Player);

				break;
			case Enum.Weapon.Type2:
				GameManager.Instance.CreatNewBullet(transform.position, transform.rotation, PlayerData.Instance.Weapon, StaticFunction.RotToVec2(transform.rotation), power,100 ,100,Enum.Owner.Player);
				break;
			case Enum.Weapon.Size:
				break;
		}
        power = 0;
        //TODO:SetCD
        cdtime = ConstData.AtkCD;
	}


	// Update is called once per frame
	void Update()
    {
        cdtime -= Time.deltaTime;
        if (cdtime > 0)
        {
            return;
        }

        if (Input.GetMouseButton(0) && cdtime < 0 && !CheckGuiRaycastObjects())
        {
            if (powerSlider == null && power > 0.2)
            {
                powerSlider = GameManager.Instance.CreatNewSlider(gameObject, 10, () => { return power / 1; }, Color.yellow, Color.black, 0, 0.4f, 1);
            }

            AddPower();
        }
        if (Input.GetMouseButtonUp(0) && !CheckGuiRaycastObjects())
        {
            Fire();
        }
    }

    //检测方法，返回false代表射线没有触碰UI层
    bool CheckGuiRaycastObjects()
    {
        PointerEventData eventData = new PointerEventData(eventsystem);
        eventData.pressPosition = Input.mousePosition;
        eventData.position = Input.mousePosition;
        List<RaycastResult> list = new List<RaycastResult>();
        graphicRaycaster.Raycast(eventData, list);

        return list.Count > 0;

    }
}
