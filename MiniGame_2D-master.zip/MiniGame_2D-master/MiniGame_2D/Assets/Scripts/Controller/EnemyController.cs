﻿using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    private SpriteRenderer render;
    private Rigidbody2D rigidbody2;
    private float health;
    private float maxHealth;
    private float initTime;
	private float beAttack;
    private TimeLock timeLock;
	private float nowSpeed;
	private bool live;
    private Enum.Enemy type;
    private Animator animator;

	public Enemy Type { get => type; }

	public EnemyController SetUp(Enum.Enemy t, float it = 0.5f, float h = 100)
    {
        health = maxHealth = ConstData.EnemyAtrTable[(int)t, (int)Enum.Attribute.Health];
        initTime = it;
        type = t;
		live = true;
        return this;
    }

    // Start is called before the first frame update
    void Start()
    {
        timeLock = new TimeLock();
        rigidbody2 = GetComponent<Rigidbody2D>();
        render = GetComponent<SpriteRenderer>();
        SetUp(Enum.Enemy.Type1);
        animator = GetComponent<Animator>();
    }

    void BeAttack(Collider2D collision, int damage, float time, float force)
    {
        if (!timeLock.Working)
        {
            timeLock.Last = time;
            GameManager.Instance.CreatNewSlider(this.gameObject, time, () => { return health / maxHealth; }, Color.red, Color.black);
            StartCoroutine(StaticFunction.RenderFlash(render, timeLock, 0.2f));
        }
		rigidbody2.velocity = (StaticFunction.NormoalSize(StaticFunction.Vec3ToVec2(transform.position - collision.transform.position), force));
		//Debug.Log(rigidbody2.velocity);
		health -= damage;
		beAttack = 0.5f;
    }

	private void OnTriggerStay2D(Collider2D collision)
	{
		if (collision.gameObject.tag == "Player")
		{
			PlayerController.Instance.BeAttack(gameObject, Mathf.Max(0, ConstData.EnemyAtrTable[(int)Type, (int)Enum.Attribute.Attack] - PlayerData.Instance.Defend), 1, 1);
		}
	}

	private void OnTriggerEnter2D(Collider2D collision)
    {
		//Debug.Log("Enemy Collider: "+collision.gameObject.tag);
		if (collision.gameObject.tag == "Player")
		{
            animator.SetBool("attack",true);
			PlayerController.Instance.BeAttack(gameObject, Mathf.Max(0, ConstData.EnemyAtrTable[(int)Type, (int)Enum.Attribute.Attack] - PlayerData.Instance.Defend), 2, 10);
        }
// =======
// 		if (collision.gameObject.tag == "Player")
// 		{
// 			PlayerController.Instance.BeAttack(gameObject, Mathf.Max(0, ConstData.EnemyAtrTable[(int)Type, (int)Enum.Attribute.Attack] - PlayerData.Instance.Defend), 1, 1);
// >>>>>>> 85130eec96ae8e6712b0eafc1a1828d1b8254df6
// 		}
		if (collision.gameObject.tag == "Bullet")
		{
			var bc = collision.gameObject.GetComponent<BulletController>();
			if (bc && bc.Owner == Enum.Owner.Player)
				BeAttack(collision, StaticFunction.DamageToEnemy(Type, bc.Power), 1, 1);
			if (health <= 0 && live)
			{
				live = false;
				GameManager.Instance.EnemyCnt--;
				GameManager.Instance.CreatNewResource(gameObject.transform.position, gameObject.transform.rotation, (Resource)Random.Range(0,(int)Resource.Size),2);
				//GameManager.Instance.CreatNewResource(gameObject.transform.position, gameObject.transform.rotation, Resource.Type1,1);
				Destroy(this.gameObject);
			}
		}
        //animator.SetBool("attack",false);
    }

	void UpdateAI()
	{
		//transform.position += (PlayerController.Instance.gameObject.transform.position - transform.position) * 0.1f;
		Vector2 look = StaticFunction.Vec3ToVec2(-transform.position + PlayerController.Instance.gameObject.transform.position);
		if (beAttack <= 0)
		{
			nowSpeed += 0.5f;
			nowSpeed = Mathf.Min(ConstData.EnemyAtrTable[(int)Type, (int)Enum.Attribute.Speed], nowSpeed);
			rigidbody2.velocity = StaticFunction.NormoalSize(look, nowSpeed);
		}
		else
		{
			beAttack -= Time.deltaTime;
		}
		rigidbody2.rotation = StaticFunction.Vec2ToRot(look);
		//Debug.Log("look"+ look);
		//Debug.Log("Enemy" + transform.position);
		//Debug.Log("player"+PlayerController.Instance.gameObject.transform.position);

		render.flipX = (look.x > 0);
	}

	// Update is called once per frame
	void Update()
    {
		//if (!timeLock.Working)
		UpdateAI();
    }
}
