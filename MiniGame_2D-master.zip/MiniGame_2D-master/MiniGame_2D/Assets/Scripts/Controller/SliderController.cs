﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderController : MonoBehaviour
{
	// Start is called before the first frame update

	private StaticFunction.GetFloat getData;
	private GameObject follow;
	private float time;
	private float speed;
	private Slider slider;
	private float movex, movey;
	public Image fill,back;

	public float Time { get => time; set => time = value; }

	public SliderController SetUp(GameObject f,float t,StaticFunction.GetFloat g, Color cf,Color cb, float x,float y,float s) {
		follow = f;
		Time = t;
		getData = g;
		movex = x;
		movey = y;
		speed = s;
		fill.color = cf;
		back.color = cb;
		slider = GetComponent<Slider>();
		transform.position = follow.transform.position + new Vector3(movex, movey, 0);
		slider.value = getData();
		return this;
	}

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
		Time -= UnityEngine.Time.deltaTime;
		if (!follow || Time < 0)
		{
			Destroy(gameObject);
		}
		else
		{
			transform.position = follow.transform.position + new Vector3(movex, movey, 0);
			slider.value = StaticFunction.CloseTo(slider.value, getData(), speed); //(slider.value - getData()) * speed;
		}
    }
}
