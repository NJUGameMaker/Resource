﻿using System;
using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{

	public static GameManager Instance = null;	// 单例 游戏唯一GameManager
	BoardController boardController;

	public string room_name;

	private GameObject UI;
	//private GameObject camera;

	public GameObject[] Bullet;
	public GameObject[] Barrier;
	public GameObject[] Enemy;
	public GameObject[] Resource;
	public GameObject Slider;
	public GameObject CanvaOnCamera;
	public int EnemyCnt;
    private string lastScene;


	private void Awake()
	{
		//Debug.Log("Awake");
		if (Instance == null){
			// 初始化单例
			Instance = this;
		}
		else if (Instance != this){
			// 单例已存在 消除现在的GameManager
			Destroy(gameObject);
		}
		// 切换场景时不消除
		DontDestroyOnLoad(gameObject);
		//PlayerData.Instance.;.l\,,](Enum.Hero.Warrior,)
		UI = GameObject.Find("UI");
		DontDestroyOnLoad(UI);
		DontDestroyOnLoad(CanvaOnCamera);
		//切换主相机
		CanvaOnCamera.GetComponent<Canvas>().worldCamera = Camera.main;
		//DontDestroyOnLoad(camera);
		lastScene = SceneManager.GetActiveScene().name;
	}


	public BulletController CreatNewBullet(Vector3 pos,Quaternion rot,Enum.Weapon type,Vector2 s,float p,float dt,float st,Enum.Owner o)
	{
		return Instantiate(Bullet[(int)type], pos, rot).GetComponent<BulletController>().SetUp(s, p, dt, st, type, o);
	}

	public BulletController CreatNewBullet(GameObject g, Enum.Weapon type, Vector2 s, float p, float dt, float st, Enum.Owner o)
	{
		return Instantiate(Bullet[(int)type],g.transform).GetComponent<BulletController>().SetUp(s, p, dt, st, type, o);
	}
    
	public void CreatNewBarrier(Vector3 pos,Quaternion rot, Enum.Barrier type)
	{
		Instantiate(Barrier[(int)type],pos,rot);
	}

	public EnemyController CreatNewEnemy(Vector3 pos, Quaternion rot, Enum.Enemy type)
	{
		EnemyCnt++;
		return Instantiate(Enemy[(int)type], pos, rot).GetComponent<EnemyController>().SetUp(type);
	}

	public SliderController CreatNewSlider(GameObject f,float t,StaticFunction.GetFloat g, Color cf,Color cb,float x = 0, float y = 0.5f,float s = 0.1f)
	{
		return Instantiate(Slider, CanvaOnCamera.transform).GetComponent<SliderController>().SetUp(f, t, g, cf, cb, x, y, s);
	}

	public ResourceController CreatNewResource(Vector3 pos, Quaternion rot, Enum.Resource type,int num = 1)
	{
		return Instantiate(Resource[(int)type], pos, rot).GetComponent<ResourceController>().SetUp(type,num);
	}

	public ResourceController CreatNewResource(Vector3 pos, Quaternion rot, Enum.Equip type, int num = 1)
	{
		return Instantiate(Resource[(int)type], pos, rot).GetComponent<ResourceController>().SetUp(type, num);
	}

	// Start is called before the first frame update
	void Start()
    {
        initial();
	}

	// Update is called once per frame
	void Update()
    {
        if(lastScene!=SceneManager.GetActiveScene().name){
            boardController.BoardSetup();
            lastScene = SceneManager.GetActiveScene().name;
        }
    	// For scene switch test
   //     if (Input.GetKey("1"))
   //     {
   //     	Debug.Log("Switch to room 1");
			//SceneManager.LoadScene("room1");
			//// Debug.Log("Set up Scene");
			//boardController.SetupScene("room1");
			//// Debug.Log("Scene Set up");
   //     }
   //     if (Input.GetKey("2"))
   //     {
   //     	Debug.Log("Switch to room 2");
			//SceneManager.LoadScene("room2");
			//boardController.SetupScene("room2");
   //     }
   //     if (Input.GetKey("3"))
   //     {
   //     	Debug.Log("Switch to room 3");
			//SceneManager.LoadScene("room3");
			//boardController.SetupScene("room3");
        //}


        if (PlayerData.Instance.Health <= 0)
        {
            PlayerController.Instance.Death();
        }


    }

    public void initial()
    {
        //Debug.Log("Start");
        // 加载场景
        boardController = GetComponent<BoardController>();
        boardController.BoardSetup();
        PlayerData.Instance.Health = PlayerData.Instance.MaxHealth;
        //<<<<<<< HEAD
        PlayerData.Instance.SetupHero(Enum.Hero.Warrior, Enum.Weapon.Type1);
        //CreatNewEnemy(new Vector3(-2, -2, 0), new Quaternion(), Enum.Enemy.Type1);
        //CreatNewEnemy(new Vector3(2, 2, 0), new Quaternion(), Enum.Enemy.Type1);
        CreatNewResource(new Vector3(1, 1, 0), new Quaternion(), Enum.Resource.Type1);
        //CreatNewSlider(GameObject.Find("Player"), 5, () => { return PlayerData.Instance.Health / PlayerData.Instance.MaxHealth; });
        //=======
        //        PlayerData.Instance.SetupHero(Enum.Hero.Warrior, Enum.Weapon.Type1);
        //      // CreatNewEnemy(new Vector3(-2, -2, 0), new Quaternion(), Enum.Enemy.Type1);
        //      // CreatNewEnemy(new Vector3(2, 2, 0), new Quaternion(), Enum.Enemy.Type1);
        //      // CreatNewResource(new Vector3(1, 1, 0), new Quaternion(), Enum.Resource.Type1);
        //      //CreatNewSlider(GameObject.Find("Player"), 5, () => { return PlayerData.Instatnce.Health / PlayerData.Instatnce.MaxHealth; });
        //>>>>>>> d0db345e425eac35313bb05e72dd10d299f2c897
    }
}
