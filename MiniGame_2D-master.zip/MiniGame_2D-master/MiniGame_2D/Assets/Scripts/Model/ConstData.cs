﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Enum
{
	public enum Hero
	{
		Warrior,
		Master,
		Size
	};

	public enum Attribute
	{
		Health,
		Attack,
		Defend,
		Speed,
		Size
	};

	public enum Door
	{
		Type1,
		Type2,
		Type3,
		Size
	};

	public enum Resource
	{
		Type1,
		Type2,
		Size
	};

	public enum Equip
	{
		Type1,
		Type2,
		Size
	};

    public enum Weapon
	{
		Type1,
		Type2,
		Size
	};

	public enum Barrier
	{
		Type1,
		Type2,
		Size
	};

	public enum Enemy
	{
		Type1,
		Type2,
		Size
	};

	public enum Owner
	{
		Player,
		Enemy,
		Size
	};

	public enum Map
	{
		Map1,
		Map2,
		Size
	}

};

class ConstData
{
	public static float AtkCD = 0.5f; // 玩家攻击间隔

	public static int Damage(int atk,int def,float pow) //伤害计算公式 玩家攻击力，敌人防御力，玩家蓄力时间
	{
		return (int) Mathf.Max(0, (pow + 1) * atk - def);
	}

	public static readonly int[,] DoorResTable = {
		{5,3 },
		{3,5 },
		{7,7 }
	};

	public static readonly int[,] HeroAtrTable = {
		{ 100,20,5,5 }, // 玩家：血量,攻击,防御,移动速度
		{ 80,20,10,4 }
	};

	public static readonly int[,] EquAtrTable ={
		{0,10,0,0 },
		{0,0,10,0 }
	};

	public static readonly int[,] EnemyAtrTable =
	{
		{50,15,15,3 }, // 敌人：血量,攻击,防御,移动速度
		{50,10,10,3 },
	};


};

public class TimeLock
{
	public bool Working { get => Last > 0; }
	public float Last { get; set; }
	public TimeLock()
	{
		Last = 0;
	}
}