﻿using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;
public class PlayerData : MonoBehaviour
{
    public static PlayerData Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            // 初始化单例
            Instance = this;
        }
        else if (Instance != this)
        {
            // 单例已存在 消除现在的GameManager
            Destroy(gameObject);
        }
        // 切换场景时不消除
        DontDestroyOnLoad(gameObject);

        resource = new int[(int)Enum.Resource.Size];
        equip = new int[(int)Enum.Equip.Size];
        door = new int[(int)Enum.Door.Size];
    }
    private Hero hero;
    private Weapon weapon;
    private int health;
    private int[] resource;
    private int[] equip;
    private int[] door;

    public float speed;
    //回血
    //public int hpRecoverAmount = 20;
    //加速
    //public float accelCoeff = 1.5f;
    //public float accelTime = 5f;
    public AudioClip AttackAudio;
    public GameObject endUI;

    public Hero Hero { get => hero; set => hero = value; }
    public Weapon Weapon { get => weapon; set => weapon = value; }
    public int Health { get => health; set => health = value; }
    public int MaxHealth { get => ConstData.HeroAtrTable[(int)hero, (int)Attribute.Health] + GetEquipData(Attribute.Health); }
    public int Attack { get => ConstData.HeroAtrTable[(int)hero, (int)Attribute.Attack] + GetEquipData(Attribute.Attack); }
    public int Defend { get => ConstData.HeroAtrTable[(int)hero, (int)Attribute.Defend] + GetEquipData(Attribute.Defend); }
    public int Speed { get => ConstData.HeroAtrTable[(int)hero, (int)Attribute.Speed] + GetEquipData(Attribute.Speed); }
    public void SetupHero(Hero h, Weapon w)
    {
        hero = h;
        weapon = w;
        health = MaxHealth;
        for (int i = 0; i < (int)Equip.Size; i++)
        {
            equip[i] = 0;
        }
        for (int i = 0; i < (int)Resource.Size; i++)
        {
            resource[i] = 0;
        }
        for (int i = 0; i < (int)Door.Size; i++)
        {
            door[i] = 0;
        }
    }
    public void ModifyResource(Resource r, int m = 1)
    {
        resource[(int)r] += m;
    }
    public void ModifyEquip(Equip e, int m)
    {
        equip[(int)e] += m;
    }
    public void ModifyDoor(Door d, int m)
    {
        door[(int)d] += m;
        for (int i = 0; i < resource.Length;++i)
        {
            resource[i] -= ConstData.DoorResTable[(int)d, i];
        }
    }
    public int GetResouce(Resource r) { return resource[(int)r]; }
    public int GetEquip(Resource e) { return equip[(int)e]; }
    public int GetDoor(Resource d) { return door[(int)d]; }
    private int GetEquipData(Attribute a)
    {
        int tmp = 0;
        for (int i = 0; i < (int)Equip.Size; i++)
        {
            tmp += equip[i] * ConstData.EquAtrTable[i, (int)a];
        }
        return tmp;
    }
}










