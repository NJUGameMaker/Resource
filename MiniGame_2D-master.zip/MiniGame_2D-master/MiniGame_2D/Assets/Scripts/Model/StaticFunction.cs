﻿using System;
using System.Collections;
using System.Collections.Generic;
using Enum;
using UnityEngine;

public class StaticFunction : MonoBehaviour
{
	public delegate float GetFloat();

	public static Vector2 RotToVec2(Quaternion rot)
	{
		return new Vector2(-Mathf.Cos(rot.eulerAngles.z / 180 * 3.14f), -Mathf.Sin(rot.eulerAngles.z / 180 * 3.14f));
	}

	public static Vector2 Vec3ToVec2(Vector3 vec)
	{
		return new Vector2(vec.x, vec.y);
	}

	public static Vector2 NormoalSize(Vector2 vec,float size)
	{
		var v = vec;
		v.Normalize();
		return v * size;
	}

	public static float Vec2ToRot(Vector2 vec)
	{
		return Mathf.Atan2(vec.y, vec.x) / 3.14f * 180;
	}


	public static IEnumerator RenderFlash(SpriteRenderer render,TimeLock l,float time)
	{
		Color c;
		for (; l.Working ;l.Last -= time*2)
		{
			if (!render)
				break;
			c = render.color;
			c.a = 0.5f;
			render.color = c;
			yield return new WaitForSeconds(time);
			if (!render)
				break;
			c = render.color;
			c.a = 1;
			render.color = c;
			yield return new WaitForSeconds(time);
		}

	}

	public static int DamageToEnemy(Enemy type,float pow)
	{
		return ConstData.Damage(PlayerData.Instance.Attack, ConstData.EnemyAtrTable[(int)type, (int)Enum.Attribute.Defend],pow);
        return (int)( PlayerData.Instance.Attack * (pow + 1) - ConstData.EnemyAtrTable[(int)type, (int)Enum.Attribute.Defend]);
	}


	public static void CloseTo(Vector2 now,Vector2 to, float speed) 
	{
		now -= (now - to) * speed;
	}

	public static float CloseTo(float now, float to, float speed)
	{
		return now - (now - to) * speed;
	}

};
