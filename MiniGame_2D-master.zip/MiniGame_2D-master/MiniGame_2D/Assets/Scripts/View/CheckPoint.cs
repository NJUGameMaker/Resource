﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheckPoint : MonoBehaviour
{
    public GameObject ChooseDoor;
    public Text hint;
    public bool isLeft;

    private bool ischoosed;
    private DoorController door = new DoorController();

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player") && !ischoosed)
        {
            //set the choose panel active
            ChooseDoor.SetActive(true);

            //choose one door
        }
        else if (other.CompareTag("Player") && ischoosed)
        {
            door.GoToNext();
        }
    }

    public void Door1Choosed()
    {
        bool success = door.SetDoor("room1", isLeft, Enum.Door.Type1);
        if (!success)
        {
            StartCoroutine(Hint());
            return;
        }
        ischoosed = true;
        door.GoToNext();
    }

    public void Door2Choosed()
    {
        bool success = door.SetDoor("room2", isLeft, Enum.Door.Type2);
        if (!success)
        {
            StartCoroutine(Hint());
            return;
        }
        ischoosed = true;
        door.GoToNext();
    }

    public void Door3Choosed()
    {
        bool success = door.SetDoor("room3", isLeft, Enum.Door.Type3);
        if (!success)
        {
            StartCoroutine(Hint());
            return;
        }
        ischoosed = true;
        door.GoToNext();
    }

    private IEnumerator Hint()
    {
        hint.transform.localScale = new Vector3(0.05f, 0.05f, 1);
        yield return new WaitForSeconds(2f);
        hint.transform.localScale = new Vector3(0, 0, 0);
    }
}
