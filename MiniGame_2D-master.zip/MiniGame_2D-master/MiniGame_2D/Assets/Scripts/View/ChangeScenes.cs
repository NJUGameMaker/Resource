﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScenes : MonoBehaviour
{
    public void startGame()
    {
        Debug.Log("Start Game");
        SceneManager.LoadScene("room1");
    }

    public void Menu()
    {
        Debug.Log("Game Menu");
        SceneManager.LoadScene("Menu");
        Destroy(GameObject.Find("UI"));
        Destroy(GameObject.Find("Player"));
    }
}
