﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ValueDisplay : MonoBehaviour
{
    private static ValueDisplay instance;
    private PlayerController player;

    public static ValueDisplay Instance
    {
        get
        {
            if (instance != null) return instance;

            else
            {
                Debug.LogError("Add instance need to display!");
                return null;
            }
        }
    }
    public Text HealthText;
    public Text Resource1;
    public Text Resource2;
    private int Health;

    public void SetHealthText()
    {
        int health = PlayerData.Instance.Health;
        if (health < 0) health = 0;

        HealthText.text = "Health: " +health.ToString();
    }

    public void SetResourceText()
    {
        Resource1.text = "Resource1: " + PlayerData.Instance.GetResouce(Enum.Resource.Type1).ToString();
        Resource2.text = "Resource2: " + PlayerData.Instance.GetResouce(Enum.Resource.Type2).ToString();
    }

    void Awake()
    {
        instance = this;
    }

    private void Update()
    {
        SetHealthText();
        SetResourceText();
    }
}