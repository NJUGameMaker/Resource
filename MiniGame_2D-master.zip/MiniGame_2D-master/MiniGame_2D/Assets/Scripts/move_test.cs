﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move_test : MonoBehaviour
{
    private Animator animator;
    private bool is_rotate = false;
    // Start is called before the first frame update
    void Start()
    {
        animator = transform.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A)){
            // left
            this.runleft();
        }
        if (Input.GetKeyDown(KeyCode.S)){
            this.rundown();
        }
        if (Input.GetKeyDown(KeyCode.D)){
            this.runright();
        }
        if (Input.GetKeyDown(KeyCode.W)){
            this.runup();
        }
        
    }

    private void runstill(){
        animator.SetBool("right",false);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
        if (is_rotate==true){
            //已经旋转
            transform.rotation = Quaternion.Euler(0, 0, 0);
            is_rotate = false;
        }
    }

    private void runleft(){
        Debug.Log("run left");
        Debug.Log(is_rotate);
        if (is_rotate==false){
            //未旋转
            transform.rotation = Quaternion.Euler(0, -180, 0);
            is_rotate = true;
        }
        animator.SetBool("right",true);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
    }

    private void rundown(){
        animator.SetBool("down",true);
        animator.SetBool("Up",false);
        animator.SetBool("right",false);
    }

    private void runright(){
        Debug.Log("run right");
        Debug.Log(is_rotate);
        if (is_rotate==true){
            //已经旋转
            transform.rotation = Quaternion.Euler(0, 0, 0);
            is_rotate = false;
        }
        animator.SetBool("right",true);
        animator.SetBool("up",false);
        animator.SetBool("down",false);
    }

    private void runup(){
        animator.SetBool("up",true);
        animator.SetBool("down",false);
        animator.SetBool("right",false);
    }
}
